#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>

int main(void)
{
	char str[10];
	int  i = 0;


	while (1)
	{

		str[i] = getchar();


		if (str[i] == '\n')
		{
			str[i + 1] = NULL;

			break;
		}

		i++;


	}

	int size = sizeof(str) / sizeof(str[0]);


	10*(size-1)

	1*(size-2)



	for (int i=0;i<size;i++)
	{



	}


	
	
	
	
	return 0;

}