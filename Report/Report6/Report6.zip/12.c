#include<stdio.h>

void set(int h, int m);
void show(void);
void move(void);

int main(void)
{



	return 0;
}


void set(int h, int m)
{

}
void show(void)
{

}
void move(void)
{

}