#include<stdio.h>
void EnterNumber()

int main(void)
{


	char 



	return 0;

}
