#include<stdio.h>

int main(void)
{

	double tall = 0, weight = 0;

	printf("Ű�� �����Ը� �Է��ϼ��� : ");
	scanf_s("%d %d", &tall, &weight);

	


	if ((tall >= 187.5) && (weight < 80))
		
		printf(" ok \n");
	
	else

		printf("cancel\n");




	return 0;


}