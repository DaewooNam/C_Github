#pragma once
#include <iostream>
using namespace std;
typedef unsigned long Item;

class Queue
{
private:
	enum {MAX = 10};
	Item items[MAX];
	int top;
	int front;
	int rear;
public :
	Queue();
	bool isempty() const;
	bool isfull() const;
	bool push(const Item &item);
	Item pop();
	//�߰� 
	void display(void); //��ü �׸� ���
	// 20  40  50  60 
	bool findValue(const Item &item);//item ã��
};