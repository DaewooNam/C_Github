#include <iostream>
//�Լ� ���ø�
template <typename T>
T sum(T a, T b)
{
	return a + b;
}

//Ŭ���� ���ø�
template <typename T>
class CMyData
{
private : 
	T m_Data;

public :
	CMyData(T Param) : m_Data(Param) {}

	T GetData() { return m_Data; }
	void SetData(T param) { m_nData = param; }
	T TestFunc();//����
};
template <typename T>
T CMyData<T>::TestFunc()//����
{
	return m_Data;
}
//���ø� �Ű�����
template <typename T, int nSize = 5 >
class CMyArray
{
public:
	CMyArray() 
	{
		m_pData = new T[nSize];
	}
	~CMyArray()
	{
		delete []m_pData;
	}
private :
	T* m_pData;
};


int main(void)
{
	std::cout << sum(10, 20) << std::endl;

	CMyData<double> a(5.2);
	std::cout << a.GetData() << std::endl;

	CMyData<int> b(5.2);
	std::cout << b.GetData() << std::endl;

	CMyData<char> c('a');
	std::cout << c.GetData() << std::endl;

	CMyData<char *> d((char*)"dongbin");
	std::cout << d.GetData() << std::endl;

	CMyArray<int, 3> e;
}