#include <iostream>
using namespace std;
int main(void)
{
	int a, b;
	int c;
	a = 100;
	b = 0;

	if (b > 0)
	{
		c = a / b;
		cout << "c = "<< c << endl;
	}
	else {
		cout << "error b = 0" << endl;
	}

	try
	{
		if (b == 0) 
		{ //���� 
			throw 3.0;
		}	else
		{
			c = a / b;
			cout << "c = " << c << endl;
		}
	} catch (int exp)
	{ 
		cout << "int "<< endl;
		cout << "error b = "<< exp << endl;
	}
	catch (double dexp)
	{
		cout << "double " << endl;
		cout << "error b = " << dexp << endl;
	}
	catch (bad_alloc allexp)
	{
		cout << "double " << endl;
		cout << "error b = " << dexp << endl;
	}

	return 0;
}