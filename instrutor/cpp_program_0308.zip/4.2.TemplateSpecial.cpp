#include <iostream>
#include <cstring>
#include <memory>

using namespace std;

template <typename T>
T sum(T a, T b)
{
	return a + b;
}

template <>
char * sum(char* chA, char* chB)
{
	int lenChA = strlen(chA);
	int lenChB = strlen(chB);
	char* pString = new char[lenChA +lenChB +1];

	strcpy_s(pString, lenChA +1, chA);
	strcpy_s(pString+lenChA, lenChB + 1, chB);

	return pString;
}

int main(void)
{
	int result;
	result = sum<double>(3, 4);
	cout << result << endl;

	char *pchresult = sum<char *>((char*)"Hello",(char *)"World");
	cout << pchresult << endl;

	delete pchresult;

	return 0;
}
