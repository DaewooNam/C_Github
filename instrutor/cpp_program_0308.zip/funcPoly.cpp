#include "funcPoly.h"

int add(int x) {
	return x;
}
int add(int x, int y)
{
	return x + y;
}
double add(double x, double y)
{
	return x + y;
}
template <typename T1, typename T2>
double mux(T1 a, T2 b)
{
	return a * b;
}
template <typename T1, typename T2, typename T3>
double mux(T1 a, T2 b, T3 c)
{
	return (a * b)*c;
}
