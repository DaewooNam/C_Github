#include <iostream>
using namespace std;
#define DEFAULT_FARE 10000
class CAnimal
{
protected :
	char gender;
};

class CPerson
{
public:
	CPerson() {}
	virtual ~CPerson() {}
	virtual void CalcFare() = 0; //��������
	int GetFare()
	{
		return fare;
	}
protected :
	int fare = 0;
};
class CBaby : public CPerson, public CAnimal
{
	virtual void CalcFare()
	{
		fare = 0;
	}
};
class CChild : public CPerson
{
	virtual void CalcFare()
	{
		fare = DEFAULT_FARE * 0.3;
	}
};
class CTeen : public CPerson
{
	virtual void CalcFare()
	{
		fare = DEFAULT_FARE * 0.5;
	}
};
class CAdult : public CPerson
{
	virtual void CalcFare()
	{
		fare = DEFAULT_FARE;
	}
};


int main(void)
{
	CPerson* aryList[3] = { 0 };
	int nAge = 0;
	for (auto &person : aryList)
	{
		cout << "���̸� �Է��Ͻÿ�.";
		cin >> nAge;
		if (nAge < 8)
		{	person = new CBaby;
		} else if(nAge < 14)
		{	person = new CChild;
		}
		else if (nAge < 20)
		{	person = new CTeen;
		}
		else {	person = new CAdult;
		}
		person->CalcFare();
	}

	for (auto person : aryList)	{
		cout << person->GetFare() << "��" << endl;
	}

	for (auto person : aryList)	{
		delete person;
	}
		return 0;
}