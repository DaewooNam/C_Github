#include <iostream>
using namespace std;

class CNode
{
	friend class CMyList;

private:
	char m_szName[32]; //string name;
	CNode *pNext = nullptr;
public:
	explicit CNode(const char*pszName)
	{
		strcpy_s(m_szName, sizeof(m_szName), pszName);
	}
};
class CMyList
{
private :
	CNode m_HeadNode;
public :
	CMyList() : m_HeadNode("Head") {}
	~CMyList() {
		CNode *pNode = m_HeadNode.pNext;
		CNode *pDelete = nullptr;

		while (pNode)
		{ 
			pDelete = pNode;
			pNode = pNode->pNext;
			cout << pDelete->m_szName << endl;
			delete pDelete;
		}
		m_HeadNode.pNext = nullptr;
	}

	void AddNewNode(const char *pszName)
	{
		CNode* pNode = new CNode(pszName);

		pNode->pNext = m_HeadNode.pNext;
		m_HeadNode.pNext = pNode;
	}
};
int main(void)
{
	CMyList list;
	list.AddNewNode("a");
	list.AddNewNode("b");
	list.AddNewNode("c");
	return 0;
}