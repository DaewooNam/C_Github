#define _CRT_SECURE_NO_WARNINGS

#include <iostream>

template <typename T>
class CMyData
{
private:
	T m_Data;
public:
	CMyData(T param) : m_Data(param)
	{	}
	T GetData() const { return m_Data; }
	void SetData(T param) { m_Data = param; }
};

template <typename T>
class CMyDataEx : public CMyData<T>
{

};

template <>
class CMyData<char *>
{
private :
	char * mp_Data;
public :
	CMyData(char* pch)
	{
		int len = strlen(pch);
		mp_Data = new char[len + 1];
		strcpy(mp_Data, pch);
	}
	~CMyData()
	{
		delete []mp_Data;
	}
	char * GetData() const
	{
		return mp_Data;
	}
};
int main(void)
{
	std::cout << "start" << std::endl;
	CMyData<char *> a((char *)"Hello World");
	std::cout << a.GetData() << std::endl;

	CMyData<int> b(10) ;
	std::cout << b.GetData() << std::endl;

	return 0;
}