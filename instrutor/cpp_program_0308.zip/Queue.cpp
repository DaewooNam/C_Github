#include "Queue.h"

Queue::Queue() //������
{
	top = 0;
	front = 0;
	rear = 0;
}
bool Queue::isempty() const
{

}
bool Queue::isfull() const
{
}

bool Queue::push(const Item &item)
{
	if (top < MAX)
	{
		items[rear] = item;
		rear = (++rear % MAX);
		top++;
		return 1;
	}
	else
	{
		return 0;
	}
}
bool Queue::push(const Item & item) {//ȿ��
	if (top < MAX) {
		for (int n = 0; n < top; n++) {
			items[top - n] = items[top - n - 1];
		}
		items[0] = item;
		top++;
		return true;
	}
	else
		return false;
}
Item Queue::pop()
{
	Item temp;
	if (top >0)
	{
		temp = items[front];
		items[front] = NULL;
		front = ++front % MAX;
		top--;
		return temp;
	}
	else
	{
		cout << "Error" << endl;
		return 0;
		exit(1);
	}
}
void Queue::display(void)
{
	cout << "Queue Contents = (";
	for (int i = 0; i < top; i++)
	{
		cout << items[front + i] << ((i < (top - 1)) ? "|" : ")");
	}
	cout << ", top : " << top << endl;
}

bool Queue::findValue(const Item &item)
{

}