#pragma once
#include <iostream>

int add(int);
int add(int, int);
double add(double, double);

template <typename T1, typename T2>
double mux(T1 a, T2 b);

template <typename T1, typename T2, typename T3>
double mux(T1 a, T2 b, T3 c);