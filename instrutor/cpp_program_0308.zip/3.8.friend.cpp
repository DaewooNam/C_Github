#include <iostream>
class CMyData
{
private :
	int m_nData;

public :
	CMyData() {}
	int GetData() const { return m_nData; }
	void SetData(int nParam) { m_nData = nParam; }

	friend void printData(const CMyData &);
};
void printData(const CMyData &cMyData)
{
	std::cout << cMyData.m_nData << std::endl;
	std::cout << cMyData.GetData() << std::endl;
}
int main(void)
{
	CMyData data;
	data.SetData(10);
	//data.GetData();
	printData(data);

	return 0;
}