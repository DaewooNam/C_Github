#define _CRT_SECURE_NO_WARNINGS

//#include <stdio.h>
#include <iostream>
using namespace std;

int main(void)
{
	int *p = new int(10);
	int *pary = new int[3];

	pary[0] = 1;
	pary[1] = 2;
	pary[2] = 3;

	cout << *p << endl;
	cout << pary[0] << " " << 
		    pary[1] << " " << 
		    pary[2] << endl;

	delete []pary; //�迭 �����Ҵ� ����
	delete p;

	return 0;
}