#include <iostream>
using namespace std;
using namespace TEST;
using namespace TEST2;

namespace TEST
{
	int testfunc(int a)
	{
		return a;
	}
}
namespace TEST2
{
	int testfunc(int a)
	{
		return a*a;
	}
}
int main(void)
{
	std::cout << TEST::testfunc(10)<< std::endl;
	std::cout << TEST2::testfunc(10);

	cout << testfunc(10) << endl;
	cout << testfunc(10) << endl;

	return 0;
}