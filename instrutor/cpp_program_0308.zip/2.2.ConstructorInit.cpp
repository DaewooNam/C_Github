#include <iostream>
using namespace std;
class CPoint
{
public :
	CPoint(int x)
	{
		cout << "CPoint(int x)" << endl;
		if (x > 100)
		{
			x = 100;
		}

		m_x = 100;
	}
	CPoint(int x, int y) : CPoint(x)
	{
		cout << "CPoint(int x, int y)" << endl;
		if (y > 200)
		{
			y = 100;
		}

		m_y = 200;
	}
	~CPoint() 
	{
		cout << "CPoint Deconstructor" << endl;
	}

	void Print()
	{
		cout << "x = " << m_x << endl;
		cout << "y = " << m_y << endl;
	}
private :
	int m_x = 0;
	int m_y = 0;
};

int main(void)
{ //�ν��Ͻ�
	CPoint xpoint(110);
	xpoint.Print();

	CPoint xypoint(50,250);
	xypoint.Print();

	return 0;
}