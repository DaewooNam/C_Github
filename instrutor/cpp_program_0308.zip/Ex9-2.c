#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
	char ch = 0;
	char aryCh[20] = {0,};
	
	FILE *pf = fopen("text.txt","r");
	
	while (1) {
		ch = fgetc(pf);
		if (ch == EOF)
		{
			break;
		}

		putchar(ch);
		if (ch == '.') 
		{
			printf("\n");
			ch = fgetc(pf);
			if (ch == ' '){ }
			else 
			{ 
				putchar(ch); 
			}
		}	
	}

	fclose (pf);
	return 0;
}