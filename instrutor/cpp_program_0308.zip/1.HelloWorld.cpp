#define _CRT_SECURE_NO_WARNINGS

//#include <stdio.h>
#include <iostream>
#include <string>

using namespace std;

int main(void)
{
	int IntData = 30;

	cout << "Hello World" << endl;
	cout << IntData << endl;
	cout << 10.5 << endl;
	cout << 3+4 << endl;

	//scanf("%d", &IntData);
	cout << IntData << endl;

	//std::cin >> IntData;
	cout << IntData << endl;

	//char szName[20];
	std::string s0("Initial string");
	s0 = "dog";
	std::cout << s0 << std::endl;

	return 0;
}
