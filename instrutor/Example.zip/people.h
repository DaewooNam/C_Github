#pragma once
#include <iostream>
#include <string>
using namespace std;

typedef struct
{
	string name;
	int age;
	char gender;
	string phoneNum;
} Person;