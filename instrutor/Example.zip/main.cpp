#include <iostream>
#include <string>
#include "func.h"
#define NUM 2
using namespace std;

int main(void)
{
	Person people[NUM];
	int size = (sizeof(people) / sizeof(people[0]));
	
	enter_person(people, size);

	for (Person &nPerson : people)
	{
		print_stru(&nPerson);
	}

	return 0;
}