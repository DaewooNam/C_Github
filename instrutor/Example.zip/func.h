#pragma once
#include "people.h"

void print_stru(Person *pPerson);
void enter_person(Person *pPerson, int size);