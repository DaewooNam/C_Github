#include <iostream>
using namespace std;

class CMyObject //
{
public:
	CMyObject() {}
	virtual ~CMyObject() {}
	virtual int GetData() = 0;
	virtual int GetID() = 0;
protected:
	int m_nData = 10;
	int ID = 0;
};
void printData(CMyObject *pObj) //�Լ�
{
	enum {TV = 1, RADIO =2, CLEANER =3};
	switch (pObj->GetID())
	{
	case TV:
		cout << "TV" << endl;
		break;
	case RADIO:
		cout << "Radio" << endl;
		break;
	case CLEANER:
		cout << "cleaner" << endl;
		break;
	default:
		break;
	}
}
class CMyTV : public CMyObject
{
public :
	virtual int GetData() { return 0; }
	virtual int GetID()
	{
		this->ID = 1;
		return ID;
	}
};
class CMyRadio : public CMyObject
{
public:
	virtual int GetData() { return 0; }
	virtual int GetID()
	{
		this->ID = 2;
		return ID;
	}
};
class CMyCleaner : public CMyObject
{
public:
	virtual int GetData() { return 0; }
	virtual int GetID()
	{
		this->ID = 3;
		return ID;
	}
};

int main(void)
{
	CMyTV tv;
	::printData(&tv);

	CMyRadio radio;
	::printData(&radio);

	CMyCleaner cleaner;
	::printData(&cleaner);
	
	return 0;
}