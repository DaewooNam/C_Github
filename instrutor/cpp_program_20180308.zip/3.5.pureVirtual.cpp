#include <iostream>
using namespace std;

class CMyInterface
{
public :
	CMyInterface() { cout << "CMyInterface" << endl; }
	virtual int GetData(void) = 0; //���� �����Լ�
	virtual void SetData(int) = 0; //���� �����Լ�
	virtual int Pow(int) = 0; //���� �����Լ�
	virtual int GCPCnt(int) = 0; //���� �����Լ�
};
class CMyData : public CMyInterface
{
public :
	CMyData() { cout << "CMyData" << endl; }
	virtual int Pow(int nParam)
	{
		return nParam * nParam;
	}
	virtual int GCPCnt(int n)
	{
		int cnt = 0;
		for (int i = 1; i <= n; i++)
		{
			if ((n % i) == 0)
			{
				cnt++;
			}
		}
		return cnt;
	}

	virtual int GetData(void)
	{
		return m_nData;
	}
	
	virtual void SetData(int nParam)
	{
		m_nData = nParam;
	}
private :
	int m_nData = 0;
};
int main(void)
{
	//CMyInterface a;
	CMyData b;
	b.SetData(5);
	cout << b.GetData() << endl;
	return 0;
}
