#include <iostream>
class CParent
{
public :
	CParent()
	{
		std::cout << "CParent" << std::endl;
		m_pzData = new char[32];
	}
	virtual ~CParent()
	{
		std::cout << "~CParent" << std::endl;
		delete m_pzData;
	}
private :
	char* m_pzData;
};
class CChild :public CParent
{
public :
	CChild()
	{
		std::cout << "CChild" << std::endl;
		m_pnData = new int;
	}
	~CChild()
	{
		std::cout << "~CChild" << std::endl;
		delete m_pnData;
	}
private:
	int *m_pnData;
};
int main(void)
{
	CParent* child = new CChild;

	delete child;

	return 0;
}