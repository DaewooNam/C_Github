#include "funcPoly.h"
using namespace std;

int main(void)
{
	cout << add(3, 5) << endl;
	cout << add(3.1, 5.2) << endl;
	cout << add(3) << endl;
	
	cout << mux(1, 2) << endl;
	cout << mux(1, 2, 3) << endl;

	return 0;
}

