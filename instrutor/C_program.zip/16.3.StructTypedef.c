#include <stdio.h>

typedef struct score
{
	int kor;
	int eng;
	int mat;
} _score;

struct score
{
	int kor;
	int eng;
	int mat;
};

int main(void)
{
	_score dongbin = { 100,50,80 };
	typedef int BYTE4;
	BYTE4 a = 10;

	printf("%d\n", dongbin.kor);


	return 0;
}