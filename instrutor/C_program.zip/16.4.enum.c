#include <stdio.h>
// 0 1 2 3
enum season { SPRING, SUMMER, FALL, WINTER };

int main(void)
{
	enum season ss;
	char* pc;

	ss = SUMMER;

	switch (ss)
	{
	case SPRING:
		printf("SPRING\n");
		break;
	case SUMMER:
		printf("SUMMER\n");
		break;
	case FALL:
		printf("SUMMER\n");
		break;		
	case WINTER:
		printf("WINTER\n");
		break;
	}
	system("pause");
	return 0;
}