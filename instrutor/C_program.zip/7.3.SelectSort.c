#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
int main(void)
{
	int array[5] = { 1 ,5 ,4 ,2 ,3 };
	int min = 1000;
	int place = 0;
	int temp = 0;

	for (int i = 0; i < 5; i++)
	{
		printf("%d", array[i]);
	}
	printf("\n");

	for (int i = 0; i < 5; i++)
	{
		min = 1000;

		for (int j = i; j < 5; j++)
		{
			if (min > array[j])
			{
				min = array[j];
				place = j;
			}
		}
		temp = array[place];
		array[place] = array[i];
		array[i] = temp;
	}

	printf("after : ");
	for (int i = 0; i < 5; i++)
	{
		printf("%d", array[i]);
	}
	printf("\n");




	return 0;
}