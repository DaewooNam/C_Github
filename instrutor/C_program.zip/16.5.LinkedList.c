#include <stdio.h>

typedef struct node
{
	int num;
	struct node* nextNodePtr;
} Node;

void print_Node(Node* nodePtr);
void attend_Node(Node* start, Node* appendNode);

int main(void)
{
	Node a, b, c;
	Node d;
	a.num = 10;
	b.num = 20;
	c.num = 30;
	d.num = 40;
	a.nextNodePtr = &b;
	b.nextNodePtr = &c;
	c.nextNodePtr = NULL;
	attend_Node(&a, &d);

	print_Node (&a);

	return 0;
}
void attend_Node(Node* start, Node* appendNode)
{
	Node *current = start;

	while (current->nextNodePtr != NULL)
	{
		current = current->nextNodePtr;
	}
	current->nextNodePtr = appendNode;
	return;
}

void print_Node(Node* nodePtr)
{
	Node * current = nodePtr;
	while (current != NULL)
	{
		printf("%d\n", current->num);
		current = current->nextNodePtr;
	}

	return;
}