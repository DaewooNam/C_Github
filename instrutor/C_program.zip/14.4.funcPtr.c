#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

void pf(int *fp); //������ 
void aryPtr(int(*fp)[3]); //�迭������
void pary(int *fp[3]); //�����͹迭
int sum(int a, int b);
int mux(int a, int b);
int div(int a, int b);
int min(int a, int b);
int remain(int a, int b);


int funcPtr(int(*fp)(int, int), int, int); //�Լ� ������



int main(void)
{
	/*int(*fp)(int, int);

	fp = sum;

	printf("sum = %d\n", sum(10,10));
	printf("fp = %d\n", fp(10,10));*/
	int x = 0;
	int y = 0;
	int result = 0;
	char op;
	printf("���� ( 10+9 ) �Է�:\n");
	scanf("%d%c%d", &x, &op, &y);

	switch(op)
	{
		case '+':
			result = funcPtr(sum, x, y);
			break;
		default:
			printf("�峭 ġ�� ���ÿ�\n");
			break;
	}
	printf("= %d",result);
	return 0;
}
int funcPtr(int(*fp)(int, int), int x, int y)
{
	return fp(x, y);
}
int sum(int a, int b)
{
	return a + b;
} 

