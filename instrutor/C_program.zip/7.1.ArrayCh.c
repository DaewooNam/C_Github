#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
int main(void)
{
	/*char arrayCh[6] = {'a','p','p','l','e','\0' };
	char arrayCh2[6] = "apple";

	for (int i = 0; i < 5; i++)
	{
		printf("%c", arrayCh2[i]);
	}

	printf("%s\n",arrayCh2);*/

	char src[20];
	char desc[20];

	strcpy(src,"beautiful");
	strcpy(desc, src);

	printf("%s\n", src);
	printf("%s\n", desc);

	return 0;
}