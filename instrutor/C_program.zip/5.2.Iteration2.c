#include < stdio.h>

int main(void)
{
	int a = 0;
	do
	{
		a = a + 2;

	} while (a < 10);

	return 0;
}