#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>

char* my_strcpy(char* dest, char*src);
int my_strlen(char *ps);
char *my_strcat(char *pd, char*ps);
int my_strcmp(char*pa, char *pb);

int main(void)
{
	/*char src[20];
	char dest[20];

	strcpy(src, "pretty");
	strcpy(dest, src);
	printf("%s %s\n", src, dest);*/
	char dest[4] = "dog";
	printf("%s", my_strcat(dest, "baby"));

	return 0;
}

int my_strlen(char *ps)
{
	int cnt = 0;
	while (*ps != '\0')
	{
		cnt++;
		ps++;
	}

	return cnt;
}

char *my_strcat(char *pd, char*ps)
{
	char * po = pd;

	while (*pd != '\0')
	{
		pd++;
	}

	while (*ps != '\0')
	{
		*pd = *ps;
		pd++;
		ps++;
	}
	*pd = '\0';

	return po;
}

int my_strcmp(char*pa, char *pb)
{
	while ((*pa == *pb) && (*pa != '\0'))
	{
		pa++;
		pb++;
	}

	if (*pa > *pb)
	{
		return 1;
	}
	else if (*pa < *pb)
	{
		return -1;
	}
	else
	{
		return 0;
	}
}