#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	char* pch;

	pch = (char*)malloc(sizeof(char) * 5);

	scanf("%s", pch);
	printf("\n%s\n", pch);

	free(pch);

	return 0;
}