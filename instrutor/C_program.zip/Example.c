#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
	int c;
	char *pch = (char *)malloc(1);
	char input[30] = { 0, };
	int idx = 0;
	int size = 0;
	printf("�޸��Է� :");
	do {
		c = getchar();
		if (c == '\n') {
			input[idx] = NULL;
			size += strlen(input);

			pch = (char *)realloc(pch, size * sizeof(char));
			if (pch == NULL) {
				printf("�޸𸮰� �����մϴ�!\n");
				exit(1);
			}
	
			strcat(pch, input);
			idx = 0;
			printf("�޸��Է� :");
		}
		else {
			input[idx] = c;
			idx++;
		}
	} while (strcmp(input, "end") != 0);
	printf("%s\n", pch);
	free(pch);

	return 0;
}