#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>

void * my_calloc(int, int);

int main(void)
{
	int *pi;
	int *pmi;
	int *pmiAfter;
	int *pmcalloc;
	//int * 5
	pi = (int *)calloc(5,sizeof(int));
	pmi = (int *)malloc(5* sizeof(int));
	pmiAfter = (int *)realloc(pi, 6 * sizeof(int));
	pmcalloc = (int *)my_calloc(5, sizeof(int));

	for (int i= 0; i < 5; i++)
	{
		//printf("%d  ", pi[i]);
		//printf("%d  ", pmi[i]);
		//printf("%d", pmiAfter[i]);
		printf("%d  ", pmcalloc[i]);
	}

	return 0;
}

void * my_calloc(int cnt, int size)
{
	int* temp;
	temp = (int *)malloc(cnt*size);

	for (int i = 0; i < cnt; i++)
	{
		temp[i] = 0;
	}

	return (void *) temp;
}
