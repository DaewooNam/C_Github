#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
int main(void)
{
	int array[5] = { 1 ,5 ,4 ,2 ,3 };
	int temp;
	printf("before : ");
	for (int i = 0; i < 5; i++)
	{
		
		printf("%d", array[i]);
	}
	printf("\n");

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (array[j] > array[j+1])
			{
				temp = array[j];
				array[j] = array[j+1];
				array[j+1] = temp;
			}
		}
	}
	printf("after : ");
	for (int i = 0; i < 5; i++)
	{
		
		printf("%d", array[i]);
	}
	printf("\n");

	return 0;
}