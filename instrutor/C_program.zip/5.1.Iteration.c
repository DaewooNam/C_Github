#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

int main(void)
{
	int i = 0;
	int j = 0;
	int num = 0;
	int sum = 0;
	int odd = 0, even = 0;
	
	scanf("%d", &num);

	for (i = 1; i <= num; i++)
	{
		sum = sum + i;
		if (i % 2 == 0)
		{
			odd = odd + i;
		}
		else
		{
			even = even + i;
		}
	}

	printf("%d\n", sum);
	printf("%d\n", odd);
	printf("%d\n", even);

	//for (j = 2; j < 10; j++) // 
	//{
	//	for (i = 1; i < 10; i++) //
	//	{
	//		printf("%d * %d = %d \n", j, i, j * i);
	//	}
	//}


	//for (j = 1; j < 10; j++) // 
	//{
	//	for (i = 2; i < 10; i++) //
	//	{
	//		if ((i != j)&&((i+j)!=11))
	//		{
	//			printf("%3d * %3d = %3d ", i, j, i*j);
	//		}
	//		else
	//		{
	//			printf("                ");
	//		}
	//	}
	//	printf("\n");
	//}
	/*
	for (j = 1; j < 10; j++) // 
	{
		for (i = 2; i < 10; i++) //
		{
				printf("%3d * %3d = %3d ", i, j, i*j);
		}
		printf("\n");
	}*/




	return 0;
}