#include <stdio.h>

int main(void)
{
	int a = 1;
	switch (a)
	{
	case 1:
		printf("1\n");
		break;
	case 2:
		printf("2\n");
	default:
		printf("default\n");
	}

	return 0;
}