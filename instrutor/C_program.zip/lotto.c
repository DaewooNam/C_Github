#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void bubleSort(int* pary, int size);
void printAry(int* pary, int size);
void printAry2(int pary[], int size);

int main(void)
{
	int lotto[6] = { 0, };
	int size = sizeof(lotto) / sizeof(lotto[0]);

	int randomNum = 0;
	srand(time(NULL));

	for (int i = 0; i < size; i++)
	{
		lotto[i] = (rand() % 45) + 1;
		for (int j = 0; j < i; j++)
		{
			if (lotto[i] == lotto[j])
			{
				i--;
				break;
			}
		}
	}

	bubleSort(lotto, size);
	printAry(lotto, size);
	printAry2(lotto, size);
	return 0;
}

void bubleSort(int* pary, int size)
{
	int temp;
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < (size - 1); j++)
		{
			if (pary[j] > pary[j + 1])
			{
				temp = pary[j];
				pary[j] = pary[j + 1];
				pary[j + 1] = temp;
			}
		}
	}
}

void printAry(int* pary, int size)
{
	for (int i = 0; i < size; i++)
	{
		printf("%d\t",pary[i]);
	}
	printf("\n");
}

void printAry2(int pary[],int size)
{
	for (int i = 0; i < size; i++)
	{
		printf("%d\t", pary[i]);
	}
	printf("\n");
}