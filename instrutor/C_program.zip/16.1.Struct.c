#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

struct student
{
	int num; //�й�
	double grade; //����
};
struct grade
{
	int math;
	int english;
	int science;
};
struct profile
{
	char name[20];
	int age;
	double height;
	struct grade pro_grd;
	char *intro;
};
int main(void)
{
	struct profile dongbin;
	struct profile sana = {"SANA",20,165.0};
	char charAry[80];

	sana.pro_grd.math = 100;
	sana.pro_grd.english = 90;
	sana.pro_grd.science = 80;

	strcpy(dongbin.name, "YEODONGBIN");
	dongbin.age = 10;
	dongbin.height = 130.0;
	dongbin.intro = (char *)malloc(80);
	gets(dongbin.intro); //scanf ���
	


	printf("�̸� : %s\n", dongbin.name);
	printf("���� : %d\n",dongbin.age);
	printf("Ű   : %.1f\n", dongbin.height);
	printf("�Ұ� : %s\n", dongbin.intro);

	printf("�̸� : %s\n", sana.name);
	printf("���� : %d\n", sana.age);
	printf("Ű   : %.1f\n", sana.height);
	

	free(dongbin.intro);











	
	return 0;
}