#include <stdio.h>

void print_str(char **ppStr, int count);

int main(void)
{
	int a = 10;
	int *pa;
	int **ppa;

	/*pa = &a;
	ppa = &pa;
	printf("����\t\t��\t�ּ�\t����\t\t������\n");
	printf("  a %12d %12u\n", a, &a);
	printf(" pa %12d %12u %12d\n", pa, &pa, *pa);
	printf("ppa %12d %12u %12d %12d\n", ppa, &ppa, *ppa, **ppa);*/

	char *ptr_str[3];
	char str1[4] = "ant";
	char str2[4] = "dog";
	char str3[4] = "cat";
	int size = sizeof(ptr_str) / sizeof(ptr_str[0]);

	ptr_str[0] = str1;
	ptr_str[1] = str2;
	ptr_str[2] = str3;

	print_str(ptr_str,size);

	return 0;
}

void print_str(char **ppStr, int count)
{
	printf("%s", ppStr[0]);

}