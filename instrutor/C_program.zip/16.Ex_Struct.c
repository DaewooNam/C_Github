#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>

typedef struct student
{
	int num;
	char name[20];
	int score[5];
	double avg;

}_student;

double print_avg(_student* pstr); //�Լ�����



int main(void)
{
	_student gaeun = { 111, "�ְ���",{ 90, 80,70,60, 50 }};

	printf("�й� : %d\n", gaeun.num);
	printf("�̸� : %s\n", gaeun.name);
	printf("���� : ");
	for (int i = 0; i < 5; i++) {
		printf("%d  ", gaeun.score[i]);
	}
	printf("\n");
	printf("��� : %.1lf\n", print_avg(&gaeun));
}

double print_avg(_student* pstr)
{
	int sum = 0;
	double avg;
	int i = 0;

	for (i = 0; i < 5; i++)
	{
		sum += pstr->score[i];
	}

	avg = ((double)sum) / 5.0;

	return avg;
}