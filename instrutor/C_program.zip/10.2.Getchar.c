#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

void my_get(char* str, int size);

int main(void)
{
	char str[20];
	int size = sizeof(str);

	my_get(str, size);
	printf("%s\n", str);

	return 0;
}

void my_get(char* str, int size)
{
	char ch;
	ch = getchar();

	for (int i = 0;(ch!='\n')&&(i<size-1);i++)
	{
		str[i] = ch;
		ch = getchar();
		str[i+1] = NULL;
	}
	
	return;
}

void my_get(char* str, int size)
{
	int i = 0;
	//printf("input: ");
	while (i<size)
	{
		str[i] = getchar();
		if (str[i] == '\n')
		{
			str[i + 1] = '\0';
			break;
		}
		i++;
	}

	printf("%s", str);
}