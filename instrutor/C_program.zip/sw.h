#pragma once
#include <stdio.h>
void print(int);

void print(int cnt)
{
	for (int i = 0; i < cnt; i++)
	{
		printf("print\n");
	}
}