#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

void main(void)
{
	int ary[3]; //ary �ּҰ�

	*(ary + 0)  = 10;
	*(ary + 1) = *(ary + 0) + 10;

	printf("\n");
	scanf("%d", ary + 2);

	for (int i = 0; i < 3; i++)
	{
		printf("%5d\t", *(ary + i));
	}

	return;
}