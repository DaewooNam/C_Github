#include <stdio.h>
#include "sw.h";

int main(void)
{
	print(5);

	return 0;
}