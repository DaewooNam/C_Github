#include <stdio.h>

int main(void)
{
	printf("%p\n","dog");
	printf("%c\n", *"dog");
	printf("%c\n", *("dog"+1));
	printf("%c\n", "dog"[2]);

	char* animal = "dog";
	printf("%s\n", animal);
	printf("%p\n",animal);
	animal = "cat";
	printf("%s\n", animal);
	printf("%p\n", animal);



	return 0;
}