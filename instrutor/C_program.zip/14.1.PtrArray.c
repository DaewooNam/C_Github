#include <stdio.h>

int main(void)
{
	/*������ �迭
	char * pary[5];

	pary[0] = "dog";
	pary[1] = "elephant";
	pary[2] = "horse";
	pary[3] = "tiger";
	pary[4] = "lion";

	for (int i = 0; i < 5; i++)
	{
		printf("%s\n", pary[i]);
		printf("%u\n", pary[i]);
	}
	printf("%c\n", *(pary[1]+1));
	printf("%c\n", pary[1][1]);*/

	//int *pary[5];
	//int num[3] = { 0, };
	//pary[0] = num;

	//*pary[0] = 10;

	int ary1[4] = { 1,2,3,4 };
	int ary2[4] = { 5,6,7,8 };
	int ary3[4] = { 9,10,11,12 };

	int *pary[3] = { ary1, ary2, ary3 };

	for (int i = 0; i < 3; i++) 
	{
		for (int j = 0; j < 3; j++) 
		{
			printf("%3d", pary[i][j]);
		}
		printf("\n");
	}
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			printf("%3d", *(pary[i] + j));
		}
		printf("\n");
	}


	return 0;
}