#include <stdio.h>

int main(void)
{
	char ch;
	char numStr[10] = { 0, };
	// \0 \0 \0 \0 \0 \0 \0 \0 \0 \0
	int i=0;

	int number = 0;
	int size = 0;

	//954
	while ((ch = getchar())!='\n')
	{
		numStr[i] = ch - '0';
		i++;
	}

	//printf("%s",numStr);

	size = strlen(numStr);
	for (int j = 0; j < size; j++)
	{
		number += numStr[j] * (int)pow(10, size - j - 1);
	}
	printf("%d",number+10);

	return 0;
}