#include <stdio.h>

int main(void)
{
	int ary[5] = {1,2,3,4,5};

	printf("%d\n", ary[0]);
	printf("%d\n", ary[1]);
	printf("%d\n", ary[2]);
	printf("%d\n", ary[3]);
	printf("%d\n", ary[4]);

	for (int i = 0; i < 5; i++)
	{
		printf("%d\n", ary[i]);
	}

	//ary[5] = { 6,7,8,9,10 };
	ary[0] = 6;
	ary[1] = 7;
	ary[2] = 8;
	ary[3] = 9;
	ary[4] = 10;

	for (int i = 0; i < 5; i++)
	{
		ary[i] = i+6;
	}

	


	return 0;
}