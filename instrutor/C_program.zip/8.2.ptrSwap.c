#include <stdio.h>

void pSwap(int* pa, int* pb);
void swap(int a, int b);
void rotate(int *pa, int*pb, int *pc);

int main(void)
{
	int a =10 , b=20 , c=30;
/*
	swap(a,b);
	printf("a= %d, b= %d\n", a, b);

	pSwap(&a, &b);
	printf("a= %d, b= %d", a, b);
*/
	rotate(&a, &b, &c);
	rotate(&a, &b, &c);
	rotate(&a, &b, &c);
	rotate(&a, &b, &c);
	rotate(&a, &b, &c);

	return 0;
}

void rotate(int *pa, int*pb, int *pc)
{
	int temp;

	temp = *pa;
	*pa = *pb;
	*pb = *pc;
	*pc = temp;

	printf("%d %d %d\n", *pa, *pb, *pc);

	return;
}



void pSwap(int* pa, int* pb)
{
	int temp;

	temp = *pa;
	*pa = *pb;
	*pb = temp;

	return;
}

void swap(int a, int b)
{
	int temp;

	temp = a;
	a = b;
	b = temp;

	return;
}