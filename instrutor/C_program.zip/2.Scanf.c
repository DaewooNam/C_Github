#include <stdio.h>

int main(void)
{
	int nInput = 0;
	nInput = 200;
	scanf_s("%d",&nInput);
	printf("%d\n", nInput);

	return 0;
}