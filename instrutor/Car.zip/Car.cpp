#include "Car.h"

int main(void)
{
	SuperCar * ae86 = new SuperCar;
	ae86->Booster();
	ae86->printSpeed();
	ae86->accele();
	ae86->printSpeed();

	delete ae86;

	return 0;
}