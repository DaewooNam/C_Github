#include "Car.h"

void SuperCar::accele(void)
{
	if (gas >= 10)
	{
		if ((GetSpeed() + 30) <= MAX_SPEED)
		{
			SetSpeed(GetSpeed() + 30);
			gas -= 10;
		}
		else
		{
			SetSpeed(MAX_SPEED);
			gas -= 10;
		}
	}
	else
	{
		SetSpeed(0);
		cout << "�⸧�� �����" << endl;
	}
}

void SuperCar::Booster(void)
{
	if ((boostrCnt == 1) && (gas > 20))
	{
		SetSpeed(GetSpeed() + 50);
		gas -= 20;
		boostrCnt -= 1;
	}
	else
	{
		cout << "Booster�� ����� �� �����ϴ�." << endl;
	}
}
void SuperCar::Charge(int _gas)
{
	int emptyGas = (60 - (this->gas));
	if (emptyGas >= _gas)
	{
		this->gas = (this->gas) + _gas;
	}
	else
	{
		cout << "gas ���Է��� �ʹ� �����ϴ�." << endl;
		cout << "���� ���ɷ��� : " << emptyGas << endl;
	}
}
void Car::black(void)
{
	if (speed >= 10)
	{
		speed -= 10;
	}
	else if (speed < 10)
	{
		this->Car::speed = 0;
	}
}
void Car::accele(void)
{
	if (gas >= 5) {
		if (speed <= 80)
		{
			speed += 20;
			gas -= 5;
		}
		else if (speed < 100)
		{
			speed = MAX_SPEED;
			gas -= 5;
			cout << "*** �ְ� �ӵ� ***" << endl;
		}
		else
		{
			speed = MAX_SPEED;
			cout << "*** �ְ� �ӵ� ***" << endl;
		}
	}
	else //�⸧����
	{
		speed = 0;
		cout << "�⸧ ����" << endl;
	}
}
void Car::printSpeed(void)
{
	cout << "gas      : " << gas << " L" << endl;
	cout << "speed    : " << speed << " km/h" << endl;
	cout << "maxSpeed : " << maxSpeed << " km/h" << endl;
}

int Car::GetSpeed(void)//���� + ����
{
	return this->speed;
}
void Car::SetSpeed(int _speed)
{
	this->speed = _speed;
}